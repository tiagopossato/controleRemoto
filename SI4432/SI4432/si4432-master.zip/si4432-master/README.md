si4432
======

Recently I got some (by mistake, lol) low-mhz (400MHz band) Si4432 based RF-Communication boards for wireless transmission of packages in RcUNO project. However, as I saw, there is not a "general purpose" library built for this chip, which seems like could be of use.

So, I decided to make one myself - and distribute freely so others can use it too, if they want to use this chip. 

So, well, let's get started!
