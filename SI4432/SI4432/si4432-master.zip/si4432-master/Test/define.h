/*
 * define.h
 *
 *  Created on: Jul 23, 2014
 *      Author: aipkin
 */

#ifndef DEFINE_H_
#define DEFINE_H_


#define TX


#endif /* DEFINE_H_ */
